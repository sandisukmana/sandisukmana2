<!DOCTYPE html>
<html>
<head>
	<title>CETAK PRINT DATA DARI DATABASE DENGAN PHP </title>
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <!-- Bootstrap -->
            <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
            <!-- styles -->
            <link href="css/styles.css" rel="stylesheet">
</head>
<body>

	<center>

		<h2>DATA LAPORAN SISWA SMK LUGINA</h2>
		
	</center>

	<?php 
	include 'koneksi.php';
	?>

	<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" >
		<tr style="background-color:blue">
                           <th>No</th>
                           <!--  <th>ID Siswa</th>  -->
                            <th>Kelas</th>
                            <th>Jurusan</th>
                            <th>NIS</th>
                            <th>Nama</th>
                            <th>Gender</th>
                            <th>Agama</th>
                            <th>TTL</th> 
                            <th>Alamat</th>
                            <th>Nama Orangtua</th>
                            <th>Alamat Orangtua</th>
                            <th>Foto</th>
                           
                    
		</tr>
		<?php 

$id=$_GET['nis'];
		$no = 1;
		
		$sql = mysqli_query($koneksi,"SELECT siswa.id_siswa,siswa.nis,siswa.foto,siswa.nama,siswa.jk, siswa.agama, siswa.tgl_lahir,siswa.tmpt_lahir,siswa.alamat,siswa.nm_ortu,siswa.alamat_ortu,siswa.foto,siswa.id_kelas,kelas.nm_kelas,kelas.tingkat,kelas.id_jur,jurusan.nm_jur,jurusan.kaprog FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id INNER JOIN jurusan ON kelas.id_jur=jurusan.id_jur where nis='$id'");
		while($data = mysqli_fetch_array($sql)){
		?> 
		<tr>
			
        <td><?= $no++; ?></td>

		 <td><?=$data['tingkat'].$data['nm_kelas']?></td>
		<td><?=$data['nm_jur']?></td>
		<td><?=$data['nis']?></td>
		<td><?=$data['nama']?></td>
		<td><?=$data['jk']?></td>
        <td><?=$data['tgl_lahir'].$data['tmpt_lahir']?></td>
		<td><?=$data['agama']?></td>
     	<td><?=$data['alamat']?></td>
     	<td><?=$data['nm_ortu']?></td>
     	<td><?=$data['alamat_ortu']?></td>
		<td><center><img src="images/<?=$data['foto']?>" width="50" height="50"></center></td>
		</tr>
		<?php 
		}
		?>
	</table>

	<script>
		window.print();
	</script>

</body>
</html>