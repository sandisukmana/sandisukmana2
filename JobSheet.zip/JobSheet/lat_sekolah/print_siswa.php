<?php

require_once __DIR__ . '/vendor/autoload.php';


$mpdf = new \Mpdf\Mpdf();

$html = '
<html>
<head>
	<title>SMK LUGINA RANCAEKEK</title>
</head>
<body>
	<h1 style="text-align: center;">Data Siswa</h1>
		<table border="1">
			<tr>
				  <th class="table-primary" style="text-align: center;">No</th>
                           <!--  <th>ID Siswa</th>  -->
                            <th class="table-primary" style="text-align: center;">Kelas</th>
                            <th class="table-primary" style="text-align: center;">Jurusan</th>
                            <th class="table-primary" style="text-align: center;">NIS</th>
                            <th class="table-primary" style="text-align: center;">Nama</th>
                            <th class="table-primary" style="text-align: center;">Gender</th>
                            <th class="table-primary" style="text-align: center;">Agama</th>
                            <th class="table-primary" style="text-align: center;">TTL</th> 
                            <th class="table-primary" style="text-align: center;">Alamat</th>
                            <th class="table-primary" style="text-align: center;">Nama Orangtua</th>
                            <th class="table-primary" style="text-align: center;">Alamat Orangtua</th>
                            <th class="table-primary" style="text-align: center;">Foto</th>
                           
			</tr>';

		include "koneksi.php";
		
$id=$_GET['id_siswa'];
		$no = 1;
		
		$sql = mysqli_query($koneksi,"SELECT siswa.id_siswa,siswa.nis,siswa.foto,siswa.nama,siswa.jk, siswa.agama, siswa.tgl_lahir,siswa.tmpt_lahir,siswa.alamat,siswa.nm_ortu,siswa.alamat_ortu,siswa.foto,siswa.id_kelas,kelas.nm_kelas,kelas.tingkat,kelas.id_jur,jurusan.nm_jur,jurusan.kaprog FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id INNER JOIN jurusan ON kelas.id_jur=jurusan.id_jur where id_siswa='$id'");
		while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
			$html .= '<tr>
					<td>'. $no++.'</td>
					<td>'. $data["nm_kelas"] .'</td>
					<td>'. $data["nm_jur"] .'</td>
					<td>'. $data["nis"] .'</td>
					<td>'. $data["nama"] .'</td>
					<td>'. $data["jk"] .'</td>
					<td>'. $data["agama"] .'</td>
					<td>'. $data["tmpt_lahir"] .','. $data["tgl_lahir"] .'</td>
					<td>'. $data["alamat"] .'</td>
					<td>'. $data["nm_ortu"] .'</td>
					<td>'. $data["alamat_ortu"] .'</td>
					"<td><img src="images/'.$data["foto"].'"  width="50" height="50"></td>


			</tr>';
		}

$html .= '</table>	
</body>
</html>';

$mpdf->WriteHTML($html);
$mpdf->Output();
?>
