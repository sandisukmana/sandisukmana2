<!DOCTYPE html>
<html>
<head>
	<title>Import Excel Ke MySQL dengan PHP - www.malasngoding.com</title>
</head>
<body style="background-image: url('images/2.jpg')">
	<style type="text/css">
	body{
		font-family: sans-serif;
	}

	p{
		color: green;
	}
</style>
<br>br
<h3 style="text-align: center;color:white;">IMPORT DATA DARI EXCEL</h3>
<a href="siswa.php" style="color: white">Kembali</a>
<br/><br/>
<?php 
include 'koneksi.php';
?>

<form method="post" enctype="multipart/form-data" action="upload_aksi.php" style="text-align: center;">

	<h3 style="color: white">Masukan File Yang Ingin Di Import</h3>
	<br>	 
	<input name="filepegawai" type="file" required="required"> 
	<br>	
	<br>	
	<input name="upload" type="submit" value="Import">
</form>

<br/><br/>


</body>
</html>