<?php
// memanggil library FPDF
require('fpdf.php');
// intance object dan memberikan pengaturan halaman PDF
$pdf = new FPDF('l','mm','A5');
// membuat halaman baru
$pdf->AddPage();
// setting jenis font yang akan digunakan
$pdf->SetFont('Arial','B',16);
// mencetak string 
$pdf->Cell(190,7,'SEKOLAH MENENGAH KEJURUSAN',0,1,'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(190,7,'DAFTAR SISWA KELAS IX JURUSAN REKAYASA PERANGKAT LUNAK',0,1,'C');

// Memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B',7);
$pdf->Cell(10,6,'nm_kelas',1,0);
$pdf->Cell(10,6,'nis',1,0);
$pdf->Cell(15,6,'nama',1,0);
$pdf->Cell(20,6,'jk',1,0);
$pdf->Cell(10,6,'agama',1,0);
$pdf->Cell(25,6,'alamat',1,0);
$pdf->Cell(25,6,'tgl_lahir',1,0);
$pdf->Cell(20,6,'tmpt_lahir',1,0);
$pdf->Cell(20,6,'alamat',1,0);
$pdf->Cell(37,6,'foto',1,1);


include 'koneksi.php';
   $sql = mysqli_query($koneksi, "SELECT siswa.id_siswa,siswa.nis,siswa.foto,siswa.nama,siswa.jk, siswa.agama, siswa.tgl_lahir,siswa.tmpt_lahir,siswa.alamat,siswa.nm_ortu,siswa.alamat_ortu,siswa.foto,siswa.id_kelas,kelas.nm_kelas,kelas.tingkat,kelas.id_jur,jurusan.nm_jur,jurusan.kaprog FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id INNER JOIN jurusan ON kelas.id_jur=jurusan.id_jur");
while ($row = mysqli_fetch_array($sql)){
    $pdf->Cell(10,6,$row['nm_kelas'],1,0);
    $pdf->Cell(10,6,$row['nis'],1,0);
    $pdf->Cell(15,6,$row['nama'],1,0);
    $pdf->Cell(20,6,$row['jk'],1,0);
    $pdf->Cell(10,6,$row['agama'],1,0);
    $pdf->Cell(25,6,$row['alamat'],1,0);
    $pdf->Cell(25,6,$row['tgl_lahir'],1,0);
    $pdf->Cell(20,6,$row['tmpt_lahir'],1,0);
    $pdf->Cell(20,6,$row['alamat'],1,0);

    $gambar=$row['foto'];
    $pdf->Image('images/' . $gambar,10,10,10);
     $pdf->Cell(37,6,$row['foto'],1,1);
}

$pdf->Output();
?>
