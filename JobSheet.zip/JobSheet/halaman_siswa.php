<?php 
session_start();
if($_SESSION['nis']==""){
  header("location:login_siswa.php?pesan=gagal");
  
}
 ?>
<html>
<head>
  <title></title>
       <link rel="icon" type="image/png" href="images/lugina.png">
        <title>SMK LUGINA RANCAEKEK</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <!-- Bootstrap -->
  <link rel="stylesheet" type="text/css" href="style.css">
              <link href="css/styles.css" rel="stylesheet">


  
</head>














<body>
  
      

<nav>

    <!--  <li><a href="cetak_kls.php"><span>cetak</span></a></li> -->
    <a href="logout_siswa.php">  <button>Logout</button> </a>
   
</nav>
  
  

<div class="container">
  <div class ="row">
    <div class="col-md-15">
      
                           
            
                           
  
  <?php
  // Load file koneksi.php
  include "koneksi.php";
  $id=$_SESSION['nis'];
  
  
  $sql = mysqli_query($koneksi,"SELECT siswa.id_siswa,siswa.nis,siswa.foto,siswa.nama,siswa.jk, siswa.agama, siswa.tgl_lahir,siswa.tmpt_lahir,siswa.alamat,siswa.nm_ortu,siswa.alamat_ortu,siswa.foto,siswa.id_kelas,kelas.nm_kelas,kelas.tingkat,kelas.id_jur,jurusan.nm_jur,jurusan.kaprog FROM siswa INNER JOIN kelas ON siswa.id_kelas = kelas.id INNER JOIN jurusan ON kelas.id_jur=jurusan.id_jur where nis='$id'");
    while($data = mysqli_fetch_array($sql)){
    ?> 
    <tr >
                  <p>Halo <b ><?php echo $_SESSION['nama']; ?></b> Anda telah login sebagai Siswa <b>



                 <h1 style="text-align: center;" >DATA DIRI ANDA</h1>
                         
      <td ><img src="images/<?=$data['foto']?>" width="150" height="150" style="display: block; margin: auto;"></td>  

    </tr>

<br>

    <table class="table table-striped table-bordered table-hover bg-danger " border=1 cellpadding=10 cellspacing=0
            align=center>
          
    <tr >
      
       <tr> 
        <th class="table-primary" style="text-align: center;">Kelas</th>
                                                                                                <td><?=$data['tingkat'].$data['nm_kelas']?></td>
            </tr>
            <tr>
                 <th class="table-primary" style="text-align: center;">Jurusan</th>
                     
                                                                                            <td><?=$data['nm_jur']?></td>
            </tr>      <!--  <th>ID Siswa</th>  -->
                          
            <tr>
              <th class="table-primary" style="text-align: center;">NIS</th>
                                                                                                <td><?=$data['nis']?></td>
            </tr>
           <tr>
             <th class="table-primary" style="text-align: center;">Nama</th>
                                                                               
                                                                                            <td><?=$data['nama']?></td>
           </tr>
           <tr>
               <th class="table-primary" style="text-align: center;">Gender</th>
                                                                                                 <td><?=$data['jk']?></td>
           </tr>
            <tr>
                         
                   <th class="table-primary" style="text-align: center;">Tanggal lahir</th> 
                       
                                                                                        <td><?=$data['tgl_lahir']?></td>  
            </tr>
 <tr>
                <th class="table-primary" style="text-align: center;">Agama</th>
                                                                                             <td><?=$data['agama']?></td>
 </tr>
    <tr>
            <th class="table-primary" style="text-align: center;">Alamat</th>
                           
                                                                                            <td><?=$data['alamat']?></td> 
  </tr>
     <tr>

           <th class="table-primary" style="text-align: center;">Nama Orangtua</th>
                  
        
                                                                                            <td><?=$data['nm_ortu']?></td> 
    </tr> 
    <tr>
         <th class="table-primary" style="text-align: center;">Alamat Orangtua</th>
                                                                                                <td><?=$data['alamat_ortu']?></td>
    </tr>
      
    
    </tr>


    <?php 
    }
    ?>

  </table>
<br>
  <!-- Footer -->
  <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Copyright &copy; 2020 - Sandi Sukmana</div>
      <br>
    </div>
  </footer>
</body>
</html>
